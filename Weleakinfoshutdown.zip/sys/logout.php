<?php
include 'system/functions.php';
session_destroy();
header("Location: /");
?>